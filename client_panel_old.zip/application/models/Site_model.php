<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Site_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insert_new_db_record($data)
    {
        return $this->db->insert('client_info', $data);
    }
}