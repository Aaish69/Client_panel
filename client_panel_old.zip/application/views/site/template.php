<!-- include your header view here -->
<?php $this->load->view('site/layout/head'); ?>

<?=$contents?>

<!-- include your footer view here -->
<?php $this->load->view('site/layout/footer'); ?>