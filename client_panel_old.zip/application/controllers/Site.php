<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Site extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        //initialize db
        //load model
        //load helper (optional)
        $this->load->model('site_model');
    }

    public function index()
    {
        $this->load->view('site_index');
        // $this->load->view('site/site_clients');
    }

    public function err_404()
    {
        $this->template->load('site/template', 'site/pages/404');
    }       
    public function client()
    {
        
        $this->template->load('site/template', 'site/pages/site_clients');
    }
    public function edit_client()
    {
        // $this->load->view('edit_clients');
        
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $data = array(
                'name'    => $_POST["name"],
                'email'   => $_POST['email'],
                'address' => $_POST['address'],
                'company' => $_POST['company'],
                'gender'  => $_POST['gender']
            );

            $this->site_model->insert_new_db_record($data);
        }

        $this->template->load('site/template', 'site/pages/edit_clients');
    }



}